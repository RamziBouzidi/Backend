from fastapi import FastAPI
from .routers import testCases, user, authentication, CarModels, microcontroller, websockets
from . import models
from .database import engine

app = FastAPI()

# Core endpoints
app.include_router(authentication.router)
app.include_router(user.router)

# Wind tunnel specific endpoints
app.include_router(CarModels.router)
app.include_router(testCases.router)
app.include_router(microcontroller.router)
app.include_router(websockets.router)

# Create all models in database
models.Base.metadata.create_all(bind=engine)








