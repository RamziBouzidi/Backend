from fastapi import APIRouter, Depends, Response, status, HTTPException
from typing import Optional
from typing import List
from .. import schema, models
from ..database import *
from ..hashpass import hashman
from ..repositories import users
from .oauth2 import get_current_user

router = APIRouter()

@router.post("/adduser", status_code=status.HTTP_201_CREATED, response_model=schema.showuser, tags=["User"])
def create(ramzi: schema.user, db: Session = Depends(get_db)):
    # No authentication required for user creation (registration)
    return users.create_user(ramzi, db)

@router.get("/getusers", status_code=status.HTTP_202_ACCEPTED, response_model=List[schema.showuser], tags=["User"])
def get_data(db: Session = Depends(get_db), current_user: schema.TokenData = Depends(get_current_user)):
    return users.get_all(db)


@router.get("/getuser/{id}", status_code=status.HTTP_200_OK, tags=["User"], response_model=schema.showuser)
def get_data(id: int, response: Response, db: Session = Depends(get_db), current_user: schema.TokenData = Depends(get_current_user)):
    return users.get_user(id, db)
    
@router.delete("/deleteUser/{id}", status_code=status.HTTP_200_OK, tags=["User"])
def delete(id: int, db: Session = Depends(get_db), current_user: schema.TokenData = Depends(get_current_user)):
    return users.delete(id, db)


@router.put("/updateUser/{id}", status_code=status.HTTP_202_ACCEPTED, tags=["User"])
def update(id: int, ramzi: schema.user, db: Session = Depends(get_db), current_user: schema.TokenData = Depends(get_current_user)):
    return users.update(id, ramzi, db)