from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect, HTTPException, status
from typing import Dict, Optional, Any, List
from datetime import datetime
from sqlalchemy.orm import Session
from .. import models, database
from ..routers.token import verify_token
import asyncio
import json

# Create router with WebSocket tag
router = APIRouter(tags=['WebSockets'])

# Store active websocket connections
microcontroller_ws: Optional[WebSocket] = None
client_connections: List[WebSocket] = []

# In-memory storage for settings and test data
memory_settings = {
    "model_id": None,
    "user_id": None,
    "device_on": False,
    "wind_speed": 0.0,
    "car_name": None,
    "last_updated": datetime.now().isoformat(),
    "drag_force": 0,
    "down_force": 0,
    "microcontroller_connected": False,
    "last_microcontroller_data": None
}

# Background task for database persistence
recording_task = None
persistence_interval = 5  # Seconds between database writes

async def record_data_to_db():
    """Background task to record test data to database only when all conditions are met for a valid test"""
    while True:
        try:
            # Only record data if:
            # 1. There are client connections
            # 2. Device is turned on
            # 3. We have valid force measurements (non-zero)
            # 4. We have valid model_id and user_id
            # 5. Microcontroller is connected or has sent data recently (within 10 seconds)
            
            current_time = datetime.now()
            microcontroller_active = memory_settings["microcontroller_connected"]
            
            # If we have a last data timestamp, check if it's recent (within 10 seconds)
            if not microcontroller_active and memory_settings["last_microcontroller_data"]:
                last_data_time = datetime.fromisoformat(memory_settings["last_microcontroller_data"])
                time_diff = (current_time - last_data_time).total_seconds()
                microcontroller_active = time_diff < 10  # Consider active if data received in last 10 seconds
            
            if (client_connections and 
                memory_settings["device_on"] and 
                memory_settings["model_id"] and 
                memory_settings["user_id"] and
                microcontroller_active):
                
                # Create a new db session for the background task
                db = next(database.get_db())
                try:
                    # Prepare test data for recording
                    test_data = {
                        "drag_force": memory_settings["drag_force"],
                        "down_force": memory_settings["down_force"],
                        "wind_speed": memory_settings["wind_speed"],
                        "model_id": memory_settings["model_id"],
                        "user_id": memory_settings["user_id"]
                    }
                    
                    # Only save if we have meaningful force data (non-zero)
                    if test_data["drag_force"] != 0 or test_data["down_force"] != 0:
                        from ..repositories.tests import save_test_data
                        await save_test_data(test_data, db)
                        print(f"Recorded completed test to database at {current_time.isoformat()}")
                except Exception as e:
                    print(f"Error recording data to database: {str(e)}")
                finally:
                    db.close()
            elif memory_settings["device_on"] and not microcontroller_active:
                print(f"Device is on but microcontroller is not connected - skipping database recording at {current_time.isoformat()}")
            
            # Wait for next recording interval
            await asyncio.sleep(persistence_interval)
        except Exception as e:
            print(f"Error in data recording task: {str(e)}")
            await asyncio.sleep(persistence_interval)  # Keep trying even if there's an error

# Start the background tasks when this module is imported
async def start_background_tasks():
    global recording_task
    if recording_task is None or recording_task.done():
        recording_task = asyncio.create_task(record_data_to_db())
        print("Started background data recording task")

# Helper function to broadcast messages to all clients
async def broadcast_to_all(message):
    """Broadcast a message to all connected clients"""
    for client in client_connections:
        try:
            await client.send_json(message)
        except Exception as e:
            print(f"Error sending to client: {str(e)}")

# Load settings from database to memory on startup
async def initialize_memory_settings(db: Session):
    """Initialize memory settings from database"""
    try:
        from ..repositories.device import get_or_create_test_settings
        settings = await get_or_create_test_settings(db)
        
        # Get car model name if available
        car_model = None
        if settings.model_id:
            car_model = db.query(models.CarModels).filter(models.CarModels.id == settings.model_id).first()
        
        # Update memory settings
        memory_settings.update({
            "model_id": settings.model_id,
            "user_id": settings.user_id,
            "device_on": settings.device_on,
            "wind_speed": settings.wind_speed,
            "car_name": car_model.car_name if car_model else None,
            "last_updated": settings.last_updated.isoformat() if settings.last_updated else datetime.now().isoformat(),
            "drag_force": 0,
            "down_force": 0,
            "microcontroller_connected": False,
            "last_microcontroller_data": None
        })
        
        print("Initialized memory settings from database")
    except Exception as e:
        print(f"Error initializing memory settings: {str(e)}")

# WebSocket endpoint for microcontroller - SINGLE CONNECTION POINT
@router.websocket("/ws/microcontroller")
async def microcontroller_websocket(websocket: WebSocket, db: Session = Depends(database.get_db)):
    global microcontroller_ws
    
    # Initialize memory settings from database if needed
    if memory_settings["model_id"] is None:
        await initialize_memory_settings(db)
    
    # Start background tasks if not already running
    await start_background_tasks()
    
    await websocket.accept()
    microcontroller_ws = websocket
    
    # Update connection status
    memory_settings["microcontroller_connected"] = True
    memory_settings["last_microcontroller_data"] = datetime.now().isoformat()
    
    try:
        # Send current settings to the microcontroller from memory
        await websocket.send_json({
            "type": "settings_update",
            "model_id": memory_settings["model_id"],
            "user_id": memory_settings["user_id"],
            "device_on": memory_settings["device_on"],
            "wind_speed": memory_settings["wind_speed"]
        })
        
        # Keep connection alive and process messages
        while True:
            # Receive data from microcontroller
            data = await websocket.receive_json()
            
            # Update last data timestamp
            memory_settings["last_microcontroller_data"] = datetime.now().isoformat()
            
            # Process different types of data
            if "drag_force" in data and "down_force" in data:
                try:
                    # Update force values in memory ONLY - database recording happens in background task
                    memory_settings["drag_force"] = data["drag_force"]
                    memory_settings["down_force"] = data["down_force"]
                    
                    # Create consistent settings format with the new force data for broadcasting
                    settings_message = {
                        "type": "settings",
                        "model_id": memory_settings["model_id"],
                        "user_id": memory_settings["user_id"],
                        "device_on": memory_settings["device_on"],
                        "wind_speed": memory_settings["wind_speed"],
                        "car_name": memory_settings["car_name"],
                        "last_updated": memory_settings["last_updated"],
                        "drag_force": data["drag_force"],
                        "down_force": data["down_force"],
                        "microcontroller_connected": True
                    }
                    
                    # Send the consistent format to all connected clients
                    await broadcast_to_all(settings_message)
                
                except Exception as e:
                    error_message = f"Error processing test data: {str(e)}"
                    print(error_message)
                    # Inform clients about the error
                    await broadcast_to_all({
                        "type": "error",
                        "message": error_message
                    })
    
    except WebSocketDisconnect:
        microcontroller_ws = None
        # Update connection status
        memory_settings["microcontroller_connected"] = False
        
        # Notify clients about the disconnection
        await broadcast_to_all({
            "type": "microcontroller_status",
            "connected": False
        })
                
    except Exception as e:
        print(f"Error in microcontroller WebSocket: {str(e)}")
        microcontroller_ws = None
        # Update connection status
        memory_settings["microcontroller_connected"] = False

# WebSocket endpoint for clients (users)
@router.websocket("/ws/client")
async def client_websocket(
    websocket: WebSocket, 
    db: Session = Depends(database.get_db)
):
    try:
        await websocket.accept()
        
        # Initialize memory settings from database if needed
        if memory_settings["model_id"] is None:
            await initialize_memory_settings(db)
        
        # Start background tasks if not already running
        await start_background_tasks()
        
        # First message must be a token verification
        try:
            initial_message = await websocket.receive_json()
            
            # Check message type
            if "type" not in initial_message or initial_message["type"] != "verificationToken":
                await websocket.send_json({
                    "type": "error",
                    "message": "First message must be of type 'verificationToken'"
                })
                await websocket.close()
                return
            
            # Verify token
            user_id = None
            if "token" in initial_message:
                try:
                    credentials_exception = HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="Could not validate credentials"
                    )
                    # Get token payload
                    token = initial_message["token"]
                    payload = verify_token(token, credentials_exception)
                    
                    # Extract email from token payload
                    email = payload.email  # From TokenData.email
                    
                    # Get user_id from email
                    user = db.query(models.User).filter(models.User.email == email).first()
                    if user:
                        user_id = user.id
                        
                        # Send authentication confirmation
                        await websocket.send_json({
                            "type": "authenticationSuccess",
                            "user_id": user_id
                        })
                    else:
                        await websocket.send_json({
                            "type": "error",
                            "message": "User not found"
                        })
                        await websocket.close()
                        return
                except Exception as e:
                    # Log the exception for debugging
                    print(f"Token verification error: {str(e)}")
                    await websocket.send_json({
                        "type": "error",
                        "message": f"Invalid token: {str(e)}"
                    })
                    await websocket.close()
                    return
            else:
                await websocket.send_json({
                    "type": "error",
                    "message": "Token is required for verification"
                })
                await websocket.close()
                return
        except json.JSONDecodeError:
            await websocket.send_json({
                "type": "error",
                "message": "Invalid JSON format in initial message"
            })
            await websocket.close()
            return
        except Exception as e:
            await websocket.send_json({
                "type": "error",
                "message": f"Error processing initial message: {str(e)}"
            })
            await websocket.close()
            return
        
        # Add to active connections
        client_connections.append(websocket)
        
        # Send current memory settings with microcontroller status immediately after successful authentication
        await websocket.send_json({
            "type": "settings",
            **memory_settings,  # Unpack all memory settings
            "microcontroller_connected": memory_settings["microcontroller_connected"]
        })
        
        # Keep connection open and handle client messages
        while True:
            try:
                message = await websocket.receive_json()
                
                # Process client commands based on message type
                try:
                    if "type" not in message:
                        await websocket.send_json({
                            "type": "error",
                            "message": "Message must include a 'type' field"
                        })
                        continue
                    
                    # Handle different message types
                    if message["type"] == "getCurrentSettings":
                        # Just send the current memory settings
                        await websocket.send_json({
                            "type": "settings",
                            **memory_settings,  # Unpack all memory settings
                            "microcontroller_connected": memory_settings["microcontroller_connected"]
                        })
                    
                    elif message["type"] == "updateSettings":
                        # Update settings in memory - NO direct database update
                        
                        # SECURITY: Always use the authenticated user_id from the token
                        # Do not allow clients to change the user_id directly
                        
                        memory_settings["user_id"] = user_id
                        
                        # Update memory with any provided settings
                        if "model_id" in message:
                            new_model_id = message["model_id"]
                            car_model = db.query(models.CarModels).filter(models.CarModels.id == new_model_id).first()
                            if car_model:
                                memory_settings["car_name"] = car_model.car_name
                            else:
                                await websocket.send_json({
                                    "type": "error",
                                    "message": f"Model ID {new_model_id} not found in database"
                                })
                                continue
                            
                            # Update car_name in memory if model ID changed
                            car_model = db.query(models.CarModels).filter(models.CarModels.id == new_model_id).first()
                            memory_settings["car_name"] = car_model.car_name if car_model else None
                        
                        if "wind_speed" in message:
                            wind_speed = message["wind_speed"]
                            if wind_speed < 0:
                                await websocket.send_json({
                                    "type": "error",
                                    "message": "Wind speed cannot be negative"
                                })
                                continue
                            memory_settings["wind_speed"] = message["wind_speed"]
                        
                        if "device_on" in message:
                            device_on = message["device_on"]
                            memory_settings["device_on"] = device_on
                            
                            # If turning device on, check microcontroller connection
                            if device_on and not memory_settings["microcontroller_connected"]:
                                # Check if we had recent data (within last 10 seconds)
                                microcontroller_active = False
                                if memory_settings["last_microcontroller_data"]:
                                    last_data_time = datetime.fromisoformat(memory_settings["last_microcontroller_data"])
                                    time_diff = (datetime.now() - last_data_time).total_seconds()
                                    microcontroller_active = time_diff < 10
                                
                                if not microcontroller_active:
                                    await websocket.send_json({
                                        "type": "warning",
                                        "message": "Device turned on but no microcontroller is connected. Data will not be recorded."
                                    })
                        
                        # Update last_updated timestamp
                        memory_settings["last_updated"] = datetime.now().isoformat()
                        
                        # Broadcast updated memory settings to all clients
                        settings_message = {
                            "type": "settings",
                            **memory_settings,  # Unpack all memory settings
                            "microcontroller_connected": memory_settings["microcontroller_connected"]
                        }
                        
                        await broadcast_to_all(settings_message)
                        
                        # Also send settings update to microcontroller (without force data)
                        if microcontroller_ws:
                            try:
                                await microcontroller_ws.send_json({
                                    "type": "settings_update",
                                    "model_id": memory_settings["model_id"],
                                    "user_id": memory_settings["user_id"],
                                    "device_on": memory_settings["device_on"],
                                    "wind_speed": memory_settings["wind_speed"]
                                })
                            except Exception as e:
                                print(f"Error sending settings to microcontroller: {str(e)}")
                    
                    else:
                        await websocket.send_json({
                            "type": "error",
                            "message": f"Unknown message type: {message['type']}"
                        })
                
                except Exception as e:
                    await websocket.send_json({
                        "type": "error",
                        "message": f"Error processing message: {str(e)}"
                    })
            except json.JSONDecodeError:
                await websocket.send_json({
                    "type": "error",
                    "message": "Invalid JSON message"
                })
            except Exception as e:
                print(f"Error in message loop: {str(e)}")
                break
                
    except WebSocketDisconnect:
        # Remove from active connections
        if websocket in client_connections:
            client_connections.remove(websocket)
    except Exception as e:
        print(f"Error in client WebSocket: {str(e)}")
        # Clean up on error
        if websocket in client_connections:
            client_connections.remove(websocket)