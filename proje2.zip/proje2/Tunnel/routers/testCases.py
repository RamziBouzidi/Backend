from fastapi import APIRouter, Depends, Response, status, HTTPException, Query, Body
from typing import Optional
from typing import List
from ..repositories import tests
from . import oauth2

from .. import schema, models
from ..database import *

router = APIRouter(tags=['TestCases'])

@router.get("/getTests", status_code=status.HTTP_202_ACCEPTED, response_model=List[schema.carmodels])
def get_tests(db: Session = Depends(get_db), current_user: schema.TokenData = Depends(oauth2.get_current_user)):
    testss = tests.get_all(db)
    if not testss:
        raise HTTPException(status_code=404, detail=f"Test cases are not available")
    return tests.get_all(db)


@router.post("/registerTests", status_code=status.HTTP_201_CREATED)
def create_tests(request: schema.testCases, db: Session = Depends(get_db), current_user: schema.TokenData = Depends(oauth2.get_current_user)):
    return tests.post_test(request, db)


@router.post("/getTestCaseById", status_code=status.HTTP_200_OK, response_model=schema.testCases)
def get_test_by_id(
    request: dict = Body(..., example={"id": 1}),
    db: Session = Depends(get_db), 
    current_user: schema.TokenData = Depends(oauth2.get_current_user)
):
    """
    Get a specific test case by its ID
    
    Request body:
    - **id**: ID of the test case to retrieve
    """
    test_id = request.get("id")
    if not test_id:
        raise HTTPException(status_code=400, detail="id is required")
    
    return tests.get_test(test_id, db)


@router.post("/getTestsByModel", status_code=status.HTTP_200_OK, response_model=List[schema.showTestcasesByUser])
def get_tests_by_model(
    request: dict = Body(..., example={"model_name": "Ferrari F40", "limit": 50}),
    db: Session = Depends(get_db), 
    current_user: schema.TokenData = Depends(oauth2.get_current_user)
):
    """
    Get recent tests for a specific car model by name
    
    Request body:
    - **model_name**: Name of the car model to retrieve tests for
    - **limit**: Number of recent test results to return (default: 50)
    """
    model_name = request.get("model_name")
    if not model_name:
        raise HTTPException(status_code=400, detail="model_name is required")
    
    limit = request.get("limit", 50)
    
    return tests.get_tests_by_model_name(model_name, limit, db)