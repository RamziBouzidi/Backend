from sqlalchemy.orm import Session
from .. import models
from fastapi import HTTPException
from .. import schema
from typing import List


def get_all(db: Session,response_model=List[schema.carmodels]):
    return db.query(models.CarModels).all()



def post_Car(request:schema.carmodels, db: Session):
    new_test = models.CarModels(car_name=request.car_name,Manufacturer=request.Manufacturer,Type_car=request.Type_car)
    db.add(new_test)
    db.commit()
    db.refresh(new_test)
    return new_test


def get_car(id: int, db: Session):
    new_test = db.query(models.CarModels).filter(models.CarModels.id == id).first()
    if not new_test:
        raise HTTPException(status_code=404,detail=f"Car with id {id} is not available")
        
    if new_test:
        return new_test
    
    
def get_car_by_name(name: str, db: Session):
    new_test = db.query(models.CarModels).filter(models.CarModels.car_name == name).first()
    if not new_test:
        raise HTTPException(status_code=404,detail=f"Car with name {name} is not available")
        
    if new_test:
        return new_test
    

def delete(id: int, db: Session):
    car = db.query(models.CarModels).filter(models.CarModels.id == id).first()
    if not car:
        raise HTTPException(status_code=404,detail=f"car with id {id} is not available")
    db.query(models.CarModels).filter(models.CarModels.id == id).delete(synchronize_session=False)
    db.commit()
    return {"message": "Model deleted successfully"}