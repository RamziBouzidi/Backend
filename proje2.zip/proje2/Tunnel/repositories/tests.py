from sqlalchemy.orm import Session
from .. import models
from fastapi import HTTPException
from .. import schema
from typing import List, Optional, Dict, Any
from datetime import datetime
from sqlalchemy import desc


def get_all(db: Session, response_model=List[schema.testCases]):
    return db.query(models.testCases).all()


def post_test(request: schema.testCases, db: Session):
    new_test = models.testCases(Down_Force=request.Down_Force, Drag_Force=request.Drag_Force, Wind_Speed=request.WindSpeed, User_Id=request.user_id, Model_id=request.Model_Id)
    db.add(new_test)
    db.commit()
    db.refresh(new_test)
    return new_test


def get_test(id: int, db: Session):
    new_test = db.query(models.testCases).filter(models.testCases.Test_id == id).first()
    if not new_test:
        raise HTTPException(status_code=404, detail=f"Test with id {id} is not available")
        
    if new_test:
        return new_test
    

def delete(id: int, db: Session):
    test = db.query(models.testCases).filter(models.testCases.Test_id == id).first()
    if not test:
        raise HTTPException(status_code=404, detail=f"test with id {id} is not available")
    db.query(models.testCases).filter(models.testCases.Test_id == id).delete(synchronize_session=False)
    db.commit()
    return {"message": "test deleted successfully"}


def get_tests_by_model_name(model_name: str, limit: int = 50, db: Session = None):
    """
    Get the most recent tests for a specific car model by name
    
    Args:
        model_name: Name of the car model
        limit: Maximum number of test results to return (default: 50)
        db: Database session
        
    Returns:
        List of testCases for the specified model, ordered by most recent first
    """
    # Find the model ID first
    car_model = db.query(models.CarModels).filter(models.CarModels.car_name == model_name).first()
    
    if not car_model:
        raise HTTPException(status_code=404, detail=f"Car model with name '{model_name}' not found")
    
    # Get tests for this model, ordered by most recent first
    tests = db.query(models.testCases)\
        .filter(models.testCases.Model_id == car_model.id)\
        .order_by(desc(models.testCases.Test_id))\
        .limit(limit)\
        .all()
    
    return tests


async def save_test_data(test_data: Dict[str, Any], db: Session):
    """
    Automatically save test data received from microcontroller to database
    
    Args:
        test_data: Dictionary containing test measurements
        db: Database session
    
    Returns:
        The newly created test case
    """
    # Create new test case
    new_test = models.testCases(
        Drag_Force=float(test_data.get('drag_force', 0)),
        Down_Force=float(test_data.get('down_force', 0)),
        Wind_Speed=float(test_data.get('wind_speed', 0)),
        Model_id=test_data.get('model_id', 1),
        User_Id=test_data.get('user_id', 1),
    )
    
    db.add(new_test)
    db.commit()
    db.refresh(new_test)
    
    return new_test


def register_test_manually(test_data: Dict[str, Any], description: Optional[str], user_id: int, db: Session):
    """
    Manually register a test with optional description
    
    Args:
        test_data: Dictionary containing test measurements
        description: Optional description for the test
        user_id: ID of the user registering the test
        db: Database session
    
    Returns:
        The newly created test case
    """
    # Create new test case
    new_test = models.testCases(
        Drag_Force=float(test_data.get('drag_force', 0)),
        Down_Force=float(test_data.get('down_force', 0)),
        Wind_Speed=float(test_data.get('wind_speed', 0)),
        Model_id=test_data.get('model_id', 1),
        User_Id=user_id,
    )
    
    # Add description if provided (would need to add this field to your model)
    # if description:
    #     new_test.description = description
    
    db.add(new_test)
    db.commit()
    db.refresh(new_test)
    
    return new_test