from sqlalchemy.orm import Session
from .. import models
from fastapi import HTTPException
from ..hashpass import hashman
from .. import schema
from datetime import datetime
from ..utils.email_service import generate_verification_code, get_code_expiry, send_verification_email, EmailConfig


def create_user(ramzi:schema.user, db: Session): 
    existing_user = db.query(models.User).filter(models.User.email == ramzi.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = hashman.hash(ramzi.password)
    new_user = models.User(
        name=ramzi.name,
        age=ramzi.age,
        email=ramzi.email,
        password=hashed_password
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

def get_all(db: Session):
    return db.query(models.User).all()

def get_user(id: int, db: Session):
    user = db.query(models.User).filter(models.User.id == id).first()
    if not user:
        raise HTTPException(status_code=404,detail=f"User with id {id} is not available")
        
    if user:
        return user
    

def delete(id: int, db: Session):
    user = db.query(models.User).filter(models.User.id == id).first()
    if not user:
        raise HTTPException(status_code=404,detail=f"User with id {id} is not available")
    db.query(models.User).filter(models.User.id == id).delete(synchronize_session=False)
    db.commit()
    return {"message": "User deleted successfully"}


def update(id: int, ramzi: schema.user, db: Session):
    user = db.query(models.User).filter(models.User.id == id).first()
    if not user:
        raise HTTPException(status_code=404,detail=f"User with id {id} is not available")
    
    # Convert Pydantic model to dict that SQLAlchemy can use
    user_data = ramzi.dict(exclude_unset=True)
    
    # Hash the password if it's being updated
    if "password" in user_data:
        user_data["password"] = hashman.hash(user_data["password"])
    
    db.query(models.User).filter(models.User.id == id).update(user_data)
    db.commit()
    return {"message": "User updated successfully"}

def start_login_verification(email: str, db: Session, email_config=None):
    """Generate and send verification code for login."""
    user = db.query(models.User).filter(models.User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail=f"User with email {email} not found")
    
    # Generate new verification code
    verification_code = generate_verification_code()
    code_expiry = get_code_expiry()
    
    # Set new code and expiry time
    user.verification_code = verification_code
    user.code_expiry = code_expiry
    user.is_verified = False
    db.commit()
    
    # Send verification email
    email_sent = send_verification_email(user.email, verification_code, config=email_config)
    if not email_sent:
        raise HTTPException(status_code=500, detail="Failed to send verification email")
    
    # Return user ID for the next step (but not the code)
    return {"message": "Verification code sent to your email", "user_id": user.id}

def verify_login_code(email: str, code: str, db: Session):
    """Verify the code submitted during login."""
    user = db.query(models.User).filter(models.User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail=f"User with email {email} not found")
    
    # Check if code is expired
    if user.code_expiry and user.code_expiry < datetime.now():
        raise HTTPException(status_code=400, detail="Verification code has expired. Please try logging in again.")
    
    # Check if code matches
    if user.verification_code != code:
        raise HTTPException(status_code=400, detail="Invalid verification code")
    
    # Mark user as verified for this session
    user.is_verified = True
    # Clear the verification code and expiry after successful verification
    user.verification_code = None
    user.code_expiry = None
    db.commit()
    
    return {"message": "Login verification successful"}