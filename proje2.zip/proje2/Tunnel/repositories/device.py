from sqlalchemy.orm import Session
from .. import models
from datetime import datetime
from fastapi import HTTPException

async def get_or_create_test_settings(db: Session):
    """Get current test settings or create if not exists"""
    settings = db.query(models.CurrentTestSettings).first()
    if not settings:
        # Get first model in database if available
        model = db.query(models.CarModels).first()
        model_id = model.id if model else 1
        
        settings = models.CurrentTestSettings(
            model_id=model_id,
            user_id=1,  # Default user
            device_on=False,
            wind_speed=0.0,
            last_updated=datetime.now()
        )
        db.add(settings)
        db.commit()
        db.refresh(settings)
    return settings

async def update_model_setting(model_id: int, user_id: int, db: Session):
    """Update the current model being tested"""
    # Verify model exists
    model = db.query(models.CarModels).filter(models.CarModels.id == model_id).first()
    if not model:
        raise HTTPException(status_code=404, detail=f"Model with ID {model_id} not found")
    
    # Update settings
    settings = await get_or_create_test_settings(db)
    settings.model_id = model_id
    settings.user_id = user_id
    settings.last_updated = datetime.now()
    db.commit()
    db.refresh(settings)
    
    return settings, model

async def update_device_control(device_on: bool, user_id: int, db: Session):
    """Update device on/off state"""
    # Update settings
    settings = await get_or_create_test_settings(db)
    settings.device_on = device_on
    settings.user_id = user_id
    settings.last_updated = datetime.now()
    db.commit()
    db.refresh(settings)
    
    return settings

async def update_wind_speed(speed: float, user_id: int, db: Session):
    """Update wind speed setting"""
    # Update settings
    settings = await get_or_create_test_settings(db)
    settings.wind_speed = speed
    settings.user_id = user_id
    settings.last_updated = datetime.now()
    db.commit()
    db.refresh(settings)
    
    return settings